//
//  MovieTableSwiftUIApp.swift
//  MovieTableSwiftUI
//
//  Created by Duyen Vu on 3/5/24.
//

import SwiftUI

@main
struct MovieTableSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
